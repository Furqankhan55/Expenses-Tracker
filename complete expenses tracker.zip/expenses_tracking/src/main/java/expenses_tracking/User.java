package expenses_tracking;

public class User {
    private int id;
    private String username;
    private String passwordHash; // Stores the hashed password from the DB
    private String email;

    // Default constructor (useful for DAO population)
    public User() {
    }

    // Constructor for creating a new user (before ID is assigned, or for initial signup)
    public User(String username, String plainPassword, String email) {
        this.username = username;
        this.passwordHash = plainPassword; // Temporarily holds plain password before hashing in DAO
        this.email = email;
    }

    // Getters
    public int getId() {
        return id;
    }

    public String getUsername() {
        return username;
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    public String getEmail() {
        return email;
    }

    // Setters
    public void setId(int id) {
        this.id = id;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setPasswordHash(String passwordHash) {
        this.passwordHash = passwordHash;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String toString() {
        return "User{" +
               "id=" + id +
               ", username='" + username + '\'' +
               ", email='" + email + '\'' +
               '}';
    }
}