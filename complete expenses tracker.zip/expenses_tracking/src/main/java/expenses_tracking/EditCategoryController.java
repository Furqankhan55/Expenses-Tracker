package expenses_tracking;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
//FXMLLoader, Parent, Scene are not strictly needed if this is a modal dialog closed by itself
// but kept for consistency if navigation pattern changes.
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

 import java.io.IOException; 
import java.math.BigDecimal; 
import java.sql.SQLException;
import java.util.Objects; 

public class EditCategoryController {

    @FXML private TextField categoryNameField;
    @FXML private TextField budgetField;
    @FXML private Label messageLabel;
    @FXML private Label currentCategoryInfoLabel; 

    private User currentUser;
    private Category categoryToEdit;
    private final CategoryDAO categoryDAO = new CategoryDAO();
    private CategoryListController categoryListController; // To refresh the list after edit

    public void setCurrentUser(User user) {
        this.currentUser = user;
    }

    public void setCategoryToEdit(Category category) {
        this.categoryToEdit = category;
        if (category != null) {
            categoryNameField.setText(category.getName());
            // Ensure budget is displayed correctly, handling null
            budgetField.setText(category.getBudget() != null ? category.getBudget().toPlainString() : "0.00");
            currentCategoryInfoLabel.setText("Editing: " + category.getName());
        } else {
            messageLabel.setText("Error: No category selected for editing.");
            // Disable fields or handle error
            categoryNameField.setDisable(true);
            budgetField.setDisable(true);
            ((Button)categoryNameField.getScene().lookup("#updateCategoryButton")).setDisable(true); // Assuming button has fx:id
        }
    }
    
    public void setCategoryListController(CategoryListController controller) {
        this.categoryListController = controller;
    }


    @FXML
    private void handleUpdateCategory(ActionEvent event) {
        if (categoryToEdit == null || currentUser == null) {
            showAlert(Alert.AlertType.ERROR, "Error", "Cannot update category. Essential data missing.");
            return;
        }

        String newName = categoryNameField.getText().trim();
        String budgetText = budgetField.getText().trim();

        if (newName.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Input Error", "Category name cannot be empty.");
            categoryNameField.requestFocus();
            return;
        }
        if (budgetText.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Input Error", "Budget cannot be empty.");
            budgetField.requestFocus();
            return;
        }

        BigDecimal newBudgetAmount;
        try {
            newBudgetAmount = new BigDecimal(budgetText); 
            if (newBudgetAmount.compareTo(BigDecimal.ZERO) < 0) {
                showAlert(Alert.AlertType.ERROR, "Input Error", "Budget cannot be negative.");
                budgetField.requestFocus();
                return;
            }
        } catch (NumberFormatException e) {
            showAlert(Alert.AlertType.ERROR, "Input Error", "Invalid budget format. Please enter a valid number (e.g., 1000.50).");
            budgetField.requestFocus();
            return;
        }

        // Check if another category with the new name already exists for this user (excluding the current one being edited)
        if (!newName.equalsIgnoreCase(categoryToEdit.getName())) { // Case-insensitive check for name change
            try {
            	
            	Category existingCategory = categoryDAO.getCategoryByNameAndUserId(newName, currentUser.getId());
                if (existingCategory != null) {
                    showAlert(Alert.AlertType.ERROR, "Input Error", "Another category with this name already exists.");
                    categoryNameField.requestFocus();
                    return;
                }
            } catch (SQLException e) {
                showAlert(Alert.AlertType.ERROR, "Database Error", "Error checking for existing category: " + e.getMessage());
                e.printStackTrace();
                return; // Stop if DB error
            }
        }

        // Update the category object
        categoryToEdit.setName(newName);
        categoryToEdit.setBudget(newBudgetAmount); 

        try {
        	
        	
            categoryDAO.updateCategory(categoryToEdit);
            showAlert(Alert.AlertType.INFORMATION, "Success", "Category updated successfully!");
            
            if (categoryListController != null) {
                categoryListController.loadCategories(); // Refresh the list in the parent controller
            }
            
            // Close the edit window/stage
            Stage stage = (Stage) categoryNameField.getScene().getWindow();
            stage.close(); 

        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Database Error", "Failed to update category: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    private void handleCancel(ActionEvent event) {
        Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        stage.close(); 
    }

    private void showAlert(Alert.AlertType type, String title, String message) {
        messageLabel.setText(message);
        if (type == Alert.AlertType.ERROR) {
            messageLabel.setStyle("-fx-text-fill: red;");
        } else if (type == Alert.AlertType.INFORMATION) {
            messageLabel.setStyle("-fx-text-fill: green;");
        } else {
            messageLabel.setStyle("-fx-text-fill: black;");
        }
        // For a more prominent alert, if needed:
        // Alert alert = new Alert(type);
        // alert.setTitle(title);
        // alert.setHeaderText(null);
        // alert.setContentText(message);
        // alert.showAndWait();
    }
}
