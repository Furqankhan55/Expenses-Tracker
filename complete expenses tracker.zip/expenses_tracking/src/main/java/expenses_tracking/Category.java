package expenses_tracking;

import java.math.BigDecimal;

public class Category {
    private int id;
    private int userId;
    private String name;
    private BigDecimal budget; // Using BigDecimal for precise financial values

    public Category() {
    }

    // Constructor for creating a new category before saving (ID is auto-generated)
    public Category(int userId, String name, BigDecimal budget) {
        this.userId = userId;
        this.name = name;
        this.budget = budget;
    }
    
    // Constructor for loading from database (includes ID)
    public Category(int id, int userId, String name, BigDecimal budget) {
        this.id = id;
        this.userId = userId;
        this.name = name;
        this.budget = budget;
    }


    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public BigDecimal getBudget() {
        return budget;
    }

    public void setBudget(BigDecimal budget) {
        this.budget = budget;
    }

    @Override
    public String toString() {
        // This is often used by ComboBoxes for display if no cell factory is set
        return name;
        // Or a more detailed representation:
        // return name + " (Budget: " + (budget != null ? budget.toPlainString() : "N/A") + ")";
    }
}
