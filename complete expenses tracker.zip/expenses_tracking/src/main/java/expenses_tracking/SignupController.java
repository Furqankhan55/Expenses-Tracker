package expenses_tracking;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Objects;
import java.util.regex.Pattern;

public class SignupController{

    @FXML private TextField usernameField;
    @FXML private TextField emailField;
    @FXML private PasswordField passwordField;
    @FXML private PasswordField confirmPasswordField;
    @FXML private Button signupButton;
    @FXML private Button loginButton; // To go back to login
    @FXML private Label messageLabel;

    private final UserDAO userDAO = new UserDAO();

    // Basic email validation pattern
    private static final Pattern EMAIL_PATTERN = Pattern.compile(
            "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$");


    @FXML
    public void initialize() {
        messageLabel.setText("");
    }

    @FXML
    private void handleSignup(ActionEvent event) {
        String username = usernameField.getText().trim();
        String email = emailField.getText().trim();
        String password = passwordField.getText(); // No trim for passwords
        String confirmPassword = confirmPasswordField.getText();

        // --- Input Validation ---
        if (username.isEmpty() || email.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Input Error", "All fields are required.");
            return;
        }
        if (username.length() < 3) {
            showAlert(Alert.AlertType.ERROR, "Input Error", "Username must be at least 3 characters long.");
            usernameField.requestFocus();
            return;
        }
        if (!EMAIL_PATTERN.matcher(email).matches()) {
            showAlert(Alert.AlertType.ERROR, "Input Error", "Invalid email format.");
            emailField.requestFocus();
            return;
        }
        if (password.length() < 6) {
            showAlert(Alert.AlertType.ERROR, "Input Error", "Password must be at least 6 characters long.");
            passwordField.requestFocus();
            return;
        }
        if (!password.equals(confirmPassword)) {
            showAlert(Alert.AlertType.ERROR, "Input Error", "Passwords do not match.");
            confirmPasswordField.clear();
            confirmPasswordField.requestFocus();
            return;
        }
        // --- End Input Validation ---


        try {
            // Check if username or email already exists
            if (userDAO.usernameExists(username)) {
                showAlert(Alert.AlertType.ERROR, "Signup Error", "Username already taken. Please choose another.");
                usernameField.requestFocus();
                return;
            }
            if (userDAO.emailExists(email)) {
                showAlert(Alert.AlertType.ERROR, "Signup Error", "Email address already registered.");
                emailField.requestFocus();
                return;
            }

            // Create a new user object (password will be hashed by DAO)
            User newUser = new User(username, password, email); // Pass plain password, DAO will hash
            userDAO.addUser(newUser);

            showAlert(Alert.AlertType.INFORMATION, "Signup Successful", "Account created successfully! You can now log in.");
            clearFields();
            // Optionally, navigate directly to login or dashboard
            handleGoToLogin(event);

        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Database Error", "An error occurred during signup: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    private void handleGoToLogin(ActionEvent event) {
        try {
            Parent loginRoot = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/Login.fxml")));
            Stage stage = (Stage) loginButton.getScene().getWindow(); // Use any button in the scene
            stage.setScene(new Scene(loginRoot));
            stage.setTitle("Expense Tracker - Login");
            stage.show();
        } catch (IOException e) {
            System.err.println("Error loading Login.fxml: " + e.getMessage());
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Navigation Error", "Could not load the login page.");
        } catch (NullPointerException e) {
            System.err.println("Error: Cannot find /Login.fxml. Ensure it is in the root of your resources folder.");
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "File Not Found", "Error: Login FXML not found.");
        }
    }
    
    private void clearFields() {
        usernameField.clear();
        emailField.clear();
        passwordField.clear();
        confirmPasswordField.clear();
        messageLabel.setText("");
    }

    private void showAlert(Alert.AlertType type, String title, String message) {
        messageLabel.setText(message);
        if (type == Alert.AlertType.ERROR) {
            messageLabel.setStyle("-fx-text-fill: red;");
        } else if (type == Alert.AlertType.INFORMATION) {
            messageLabel.setStyle("-fx-text-fill: green;");
        } else {
            messageLabel.setStyle("-fx-text-fill: black;");
        }
        // Alert alert = new Alert(type);
        // alert.setTitle(title);
        // alert.setHeaderText(null);
        // alert.setContentText(message);
        // alert.showAndWait();
    }
}





















/*package expenses_tracking;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Objects;
import java.util.regex.Pattern;

public class SignupController {

    @FXML private TextField usernameField;
    @FXML private TextField emailField;
    @FXML private PasswordField passwordField;
    @FXML private PasswordField confirmPasswordField;
    @FXML private Button signupButton;
    @FXML private Button loginButton; // To go back to login
    @FXML private Label messageLabel;

    private final UserDAO userDAO = new UserDAO();

    // Basic email validation pattern (RFC 5322 compliant, but simplified)
    private static final Pattern EMAIL_PATTERN = Pattern.compile(
            "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$");

    /**
     * Initializes the controller after its root element has been completely processed.
     * Clears any initial messages from the message label.
     
    @FXML
    public void initialize() {
        messageLabel.setText("");
    }

    /**
     * Handles the signup action when the signup button is clicked.
     * Validates input, attempts to register the user, and navigates to the login page on success.
     * @param event The ActionEvent triggered by the signup button.
     
    @FXML
    private void handleSignup(ActionEvent event) {
        String username = usernameField.getText().trim();
        String email = emailField.getText().trim();
        String password = passwordField.getText(); // No trim for passwords
        String confirmPassword = confirmPasswordField.getText();

        // --- Input Validation ---
        if (username.isEmpty() || email.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Input Error", "All fields are required.");
            return;
        }
        if (username.length() < 3) {
            showAlert(Alert.AlertType.ERROR, "Input Error", "Username must be at least 3 characters long.");
            usernameField.requestFocus(); // Set focus to the problematic field
            return;
        }
        if (!EMAIL_PATTERN.matcher(email).matches()) {
            showAlert(Alert.AlertType.ERROR, "Input Error", "Invalid email format.");
            emailField.requestFocus();
            return;
        }
        if (password.length() < 6) {
            showAlert(Alert.AlertType.ERROR, "Input Error", "Password must be at least 6 characters long.");
            passwordField.requestFocus();
            return;
        }
        if (!password.equals(confirmPassword)) {
            showAlert(Alert.AlertType.ERROR, "Input Error", "Passwords do not match.");
            confirmPasswordField.clear(); // Clear confirm password for re-entry
            confirmPasswordField.requestFocus();
            return;
        }
        // --- End Input Validation ---

        try {
            // Check if username or email already exists in the database
            if (userDAO.usernameExists(username)) {
                showAlert(Alert.AlertType.ERROR, "Signup Error", "Username already taken. Please choose another.");
                usernameField.requestFocus();
                return;
            }
            if (userDAO.emailExists(email)) {
                showAlert(Alert.AlertType.ERROR, "Signup Error", "Email address already registered.");
                emailField.requestFocus();
                return;
            }

            // Create a new User object. The UserDAO will handle password hashing.
            User newUser = new User(username, password, email); // Pass plain password, DAO will hash
            userDAO.addUser(newUser);

            showAlert(Alert.AlertType.INFORMATION, "Signup Successful", "Account created successfully! You can now log in.");
            clearFields(); // Clear the input fields after successful signup
            
            // Navigate to the login page after successful signup
            handleGoToLogin(event);

        } catch (SQLException e) {
            System.err.println("Database error during signup: " + e.getMessage());
            e.printStackTrace();
            // Generic error message for database issues
            showAlert(Alert.AlertType.ERROR, "Database Error", "An unexpected error occurred during signup. Please try again later.");
        }
    }

    /**
     * Handles the action to navigate back to the login page.
     * @param event The ActionEvent triggered by the login button.
     
    @FXML
    private void handleGoToLogin(ActionEvent event) {
        try {
            Parent loginRoot = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/Login.fxml")));
            Stage stage = (Stage) loginButton.getScene().getWindow(); // Use any button in the scene to get the stage
            stage.setScene(new Scene(loginRoot));
            stage.setTitle("Expense Tracker - Login");
            stage.show();
        } catch (IOException e) {
            System.err.println("Error loading Login.fxml: " + e.getMessage());
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Navigation Error", "Could not load the login page.");
        } catch (NullPointerException e) {
            // This usually means the FXML file was not found
            System.err.println("Error: Cannot find /Login.fxml. Ensure it is in the root of your resources folder.");
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "File Not Found", "Error: Login FXML not found.");
        }
    }
    
    /**
     * Clears all input fields and the message label on the signup form.
     
    private void clearFields() {
        usernameField.clear();
        emailField.clear();
        passwordField.clear();
        confirmPasswordField.clear();
        messageLabel.setText(""); // Clear any previous messages
    }

    /**
     * Displays an alert message to the user using the messageLabel.
     * The message color changes based on the alert type.
     * Uncomment the commented section to use a standard JavaFX Alert dialog instead.
     *
     * @param type The type of alert (e.g., ERROR, INFORMATION).
     * @param title The title for the alert (used if a standard Alert dialog is enabled).
     * @param message The message text to display.
     
    private void showAlert(Alert.AlertType type, String title, String message) {
        messageLabel.setText(message);
        if (type == Alert.AlertType.ERROR) {
            messageLabel.setStyle("-fx-text-fill: red;");
        } else if (type == Alert.AlertType.INFORMATION) {
            messageLabel.setStyle("-fx-text-fill: green;");
        } else {
            messageLabel.setStyle("-fx-text-fill: black;"); // Default or for other types
        }
        // For more prominent alerts, you can use the Alert dialog:
        /*
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null); // Or provide a header
        alert.setContentText(message);
        alert.showAndWait();
        
    }
}*/